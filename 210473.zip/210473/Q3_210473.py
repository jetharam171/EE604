import cv2
import numpy as np
def getSkewAngle(cvImage) -> float:
    newImage = cvImage.copy()
    gray = cv2.cvtColor(newImage, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (9, 9), 0)
    thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    # Apply dilate to merge text into meaningful lines/paragraphs.
    # Use larger kernel on X axis to merge characters into single line, cancelling out any spaces.
    # But use smaller kernel on Y axis to separate between different blocks of text and obtain angle
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (30, 5))
    dilate = cv2.dilate(thresh, kernel, iterations=2)
    # Find all contours
    contours, hierarchy = cv2.findContours(dilate, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key = cv2.contourArea, reverse = True)
    for c in contours:
        rect = cv2.boundingRect(c)
        x,y,w,h = rect
        cv2.rectangle(newImage,(x,y),(x+w,y+h),(0,255,0),2)
    # Find largest contour and surround in min area box
    largestContour = contours[0]
    print (len(contours))
    minAreaRect = cv2.minAreaRect(largestContour)
    cv2.imwrite("temp/boxes.jpg", newImage)
    # Determine the angle. Convert it to the value that was originally used to obtain skewed image
    angle = minAreaRect[-1]
    if angle ==90:#3_b and case when completly reverse
        return 0
    elif angle==0:
        return angle
    elif angle==45:
        return -1*angle
    elif angle==135:
        return angle
    elif angle==180:
        return angle
    elif angle==-45:
        return angle    
    elif angle <0 and angle>-45:
        return 45+angle
    elif angle <= -45:
        angle = 45 - angle
        return -1.0 * angle
    elif angle>0 and angle<45 :#3_a
         return -1*angle
    elif angle>45 and angle<90 :#3_c
         return -1*angle-90
    elif angle>90 and angle<135 :
        angle = angle-90
        return angle
    elif angle>135 and angle<180 :
        angle = angle-180
        return -1*angle
    elif angle==180:
        return 0
    else :
        #angle = 45 - angle
        return 180+1.0*angle
# Rotate the image around its center
def rotateImage(cvImage, angle: float):
    newImage = cvImage.copy()
    (h, w) = newImage.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    newImage = cv2.warpAffine(newImage, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    return newImage

def deskew(cvImage):
    angle = getSkewAngle(cvImage)
    return rotateImage(cvImage, -1.0 * angle)

def solution(image_path):
    ############################
    ############################

    ############################
    ############################
    ## comment the line below before submitting else your code wont be executed##
    # pass
    new = cv2.imread(image_path)
    fixed = deskew(new)
    cv2.imwrite("rotated_fixed.jpg", fixed) 
    return fixed
