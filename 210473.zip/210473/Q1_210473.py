import cv2
import numpy as np

# Usage
def solution(image_path):
    # white background
    height, width = 600, 600 
    flag_image = np.ones((height, width, 3), np.uint8) * 255

    # Calculate the heights of the three rectangles
    stripe_height = height // 3

    #saffron rectangle (top)
    cv2.rectangle(flag_image, (0, 0), (width, stripe_height), (60,170,255), -1)

    #white rectangle (middle)
    cv2.rectangle(flag_image, (0, stripe_height), (width, 2 * stripe_height), (255, 255, 255), -1)

    # green rectangle (bottom)
    cv2.rectangle(flag_image, (0, 2 * stripe_height), (width, 3 * stripe_height), (0, 128, 0), -1)

    #Ashoka Chakra (circle)
    center_coordinates = (width // 2, height // 2)
    radius = 100  # Radius of the Ashoka Chakra
    color = (0, 0, 255)  #  blue
    thickness = 2  # spokes thickness
    spoke_color=(255,0,0)
    #circle
    cv2.circle(flag_image, center_coordinates, radius, spoke_color, thickness)
     #input_image=cv2.imread('abc.jpg')
     #reference_flag_image = draw_indian_flag(input_image)
     #cv2.imwrite('reference_flag_image.jpg', reference_flag_image)

    # Draw the 24 spokes
    for i in range(24):
        angle = i * 15
        x1 = 300 
        y1 = 300 
        x2 = int(center_coordinates[0] + (radius ) * np.cos(np.radians(angle)))
        y2 = int(center_coordinates[1] + (radius ) * np.sin(np.radians(angle)))
        cv2.line(flag_image, (x1, y1), (x2, y2), spoke_color, 2)

    return flag_image
