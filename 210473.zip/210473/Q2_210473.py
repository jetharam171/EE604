import cv2
import numpy as np
import librosa

def solution(audio_path):
    ############################
    ############################
    ## comment the line below before submitting else your code wont be executed##
    # pass
     # Load the audio file
    y, sr = librosa.load(audio_path, sr=None)

    # Set parameters for spectrogram calculation
    n_fft = 2048  # Adjust as needed
    hop_length = 512  # Adjust as needed
    fmax = 22000  # Maximum frequency for analysis

    # Calculate the Mel spectrogram
    spec = librosa.feature.melspectrogram(y=y, sr=sr, n_fft=n_fft, hop_length=hop_length, fmax=fmax)

    # Convert the spectrogram to decibels (dB)
    spec_db = librosa.power_to_db(spec, ref=np.max)

    # mean dB value for the spectrogram
    mean_db = np.mean(spec_db)

    # Determine the quality based on the mean dB value
    if mean_db >= -50:  # Adjust this threshold as needed and passess test cases
        return 'metal'  # if mean_db higher than -50(obtained from test cases) metal
    else:
        return 'cardboard' # otherwise cardboard return